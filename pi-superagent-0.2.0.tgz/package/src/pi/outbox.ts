/** The write side of the anti-replay rule: a restart posts no answer twice, on any channel. */
import type { OutboundMessage, Outbox as OutboxPort, ReplyStatus } from '../core/index.ts'

export interface CommentSink {
  /** Whether this sink can address the message on its channel. */
  accepts(message: OutboundMessage): boolean
  /** `retry` means an earlier attempt may have landed before the process died: look before posting again. */
  post(message: OutboundMessage, text: string, retry: boolean): void | Promise<void>
}

export interface OutboxStore {
  get<T>(key: string): T | undefined
  set(key: string, value: unknown): void
}

const KEY = 'outbox'
const KEEP_SENT_MS = 30 * 86_400_000

type Row = { message: OutboundMessage; status: ReplyStatus; at: string; tries?: number }

/** A row that will never be posted again keeps its id and status, not its words: only `status(id)` reads it
 *  later, and the ledger is one blob rewritten on every send (2026-11-11: 2,223 rows, 5.0 MB, ~3 rewrites a message). */
const settle = (row: Row, status: ReplyStatus): void => {
  row.status = status
  row.message = { ...row.message, text: '' }
}

export class CommentOutbox implements OutboxPort {
  private rows: Record<string, Row>
  private readonly posting = new Set<string>()

  constructor(private readonly sink: CommentSink, private readonly store: OutboxStore,
              private readonly now: () => number = () => Date.now(),
              private readonly maxTries = 12,
              private readonly gaveUp: (message: OutboundMessage, tries: number, error: string) => void = () => {}) {
    this.rows = this.store.get<Record<string, Row>>(KEY) ?? {}
    // Rows written before settling dropped the words, and rows with no date (which never expired), are put right once.
    let fixed = false
    for (const row of Object.values(this.rows)) {
      if (!row.at) { row.at = new Date(this.now()).toISOString(); fixed = true }
      if ((row.status === 'sent' || row.status === 'dropped') && row.message.text) { row.message = { ...row.message, text: '' }; fixed = true }
    }
    if (fixed) this.persist()
  }

  private persist(): void { this.store.set(KEY, this.rows) }

  /**
   * Waits for the posts this process has in flight. A channel write that must follow a reply — closing the
   * issue a ticket just answered — has to come after the reply lands, or the thread reads as a request that
   * vanished rather than an answer that ended.
   */
  async drained(): Promise<void> {
    while (this.posting.size) await new Promise<void>(resolve => setTimeout(resolve, 5))
  }

  /** A failed post stays pending: marking it sent after an exception is success reported out of nothing. A channel
   *  that answers the same way every time (a 404 for a repository this account cannot see) is no transient fault:
   *  past the budget the reply is dropped, and the give-up is said once, out loud. */
  // The caller persists: a flush writes the ledger once, not once per row it touched.
  private failed(row: Row, error: unknown): void {
    if (row.tries && row.tries >= this.maxTries) {
      this.gaveUp(row.message, row.tries, String(error).slice(0, 200))
      settle(row, 'dropped')
    }
  }

  send(message: OutboundMessage): void {
    // Idempotent by id: the engine re-runs a command after a crash.
    if (this.rows[message.id]) return
    this.rows[message.id] = { message, status: 'pending', at: new Date().toISOString() }
    this.persist()
  }

  status(id: string): ReplyStatus | undefined { return this.rows[id]?.status }

  withdraw(id: string): void {
    if (this.rows[id]?.status === 'pending') { delete this.rows[id]; this.persist() }
  }

  flush(): number {
    let sent = 0
    let touched = false
    // Send-once only has to outlive a restart; a ledger of every message ever posted is just growth. A reply
    // the channel refused forever (a repository this account cannot see) ages out on the same clock.
    for (const [id, row] of Object.entries(this.rows)) {
      if ((row.status === 'sent' || row.status === 'dropped') && Date.parse(row.at) < this.now() - KEEP_SENT_MS) { delete this.rows[id]; touched = true }
    }
    for (const [id, row] of Object.entries(this.rows)) {
      if (row.status !== 'pending' || this.posting.has(id)) continue
      if (!this.sink.accepts(row.message)) {
        settle(row, 'dropped')
        touched = true
        continue
      }
      try {
        // Counted before the post, so an attempt that dies with the process still counts.
        row.tries = (row.tries ?? 0) + 1
        this.persist()
        const posted = this.sink.post(row.message, row.message.text, row.tries > 1)
        if (posted instanceof Promise) {
          // Sent only once the channel says so; a failed post stays pending for the next flush.
          this.posting.add(id)
          posted.then(() => { settle(row, 'sent'); this.persist() }, error => { this.failed(row, error); this.persist() }).finally(() => this.posting.delete(id))
          sent++
          continue
        }
        settle(row, 'sent')
        touched = true
        sent++
      } catch (error) {
        const before = row.status
        this.failed(row, error)
        if (row.status !== before) touched = true
      }
    }
    // The ledger is one blob, and the tick flushes it twice: persisting an untouched one measured 5,700
    // identical writes a day on an idle router.
    if (touched) this.persist()
    return sent
  }

  pending(): string[] { return Object.entries(this.rows).filter(([, r]) => r.status === 'pending').map(([id]) => id) }
}
